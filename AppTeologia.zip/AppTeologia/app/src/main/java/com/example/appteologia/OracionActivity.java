package com.example.appteologia;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class OracionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agg);
    }

    public void OracionToHome(View view){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}
